# Bộ cảnh giải thích Humanoid Skill Learning

Hai tình huống, mỗi tình huống 9 cảnh: visual (đổi ánh sáng, gắp hụt) và
contact (gắp rồi trượt). Ảnh 1280x720 có màn hình workflow và chú thích tiếng Việt.

Đây là ảnh AI và giao diện minh họa quy trình đề xuất, chưa phải kết quả huấn luyện
hay bản ghi robot thực hiện của đội. Cảnh đặt đúng mô tả kết quả kỳ vọng.
Robot trên hình là humanoid minh họa; không là ảnh hay mô hình chính xác của GR1.

Video 72 giây dùng 9 cảnh visual, chuyển cảnh nhẹ, chú thích trên hình, không lời đọc.
Nguyên bản ảnh AI, prompt và nội dung các cảnh được kèm để chỉnh sửa và tái sử dụng.
